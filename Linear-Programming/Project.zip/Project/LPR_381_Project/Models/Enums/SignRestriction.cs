﻿
namespace Common
{
    public enum SignRestriction
    {
        Positive,
        Negative,
        Unrestricted,
        Integer,
        Binary
    }
}
