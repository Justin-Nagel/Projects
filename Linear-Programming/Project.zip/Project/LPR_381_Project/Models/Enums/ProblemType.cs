﻿namespace Common
{
    public enum ProblemType
    {
        Maximization,
        Minimization
    }
}
