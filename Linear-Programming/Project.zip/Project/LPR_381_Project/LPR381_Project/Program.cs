﻿using Presentation;
using System;

namespace LPR381_Project
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            MainMenu.Run();
            Console.ReadKey();
        }
    }
}
